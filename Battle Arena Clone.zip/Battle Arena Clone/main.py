#ONABEL ALEXANDER CEDANO DE LA ROSA
#21-SISN-2-068

import pygame
import sys
import random

# Inicializar Pygame
pygame.init()

# Configuración de la pantalla
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Battle Arena")

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Fuentes
font = pygame.font.SysFont("Arial", 40)

# Música y sonidos
pygame.mixer.music.load("Battle Arena.mp3")  # Asegúrate de tener la música
pygame.mixer.music.play(-1, 0.0)  # Reproducir en bucle
disparo_sound = pygame.mixer.Sound("lasergun.mp3")  # Asegúrate de tener el sonido

# Cargar imágenes de fondo
try:
    menu_background_image = pygame.image.load("arena.jpg")  # Imagen de fondo para el menú
    game_background_image = pygame.image.load("fondo.png")  # Imagen de fondo para el juego
    game_background_image = pygame.transform.scale(game_background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))  # Ajustar al tamaño de la pantalla
except pygame.error as e:
    print(f"No se pudo cargar la imagen de fondo: {e}")
    pygame.quit()
    sys.exit()

# Función para mostrar texto
def draw_text(text, font, color, surface, x, y):
    textobj = font.render(text, 1, color)
    textrect = textobj.get_rect()
    textrect.topleft = (x, y)
    surface.blit(textobj, textrect)

# Función de menú principal
def main_menu():
    while True:
        screen.blit(menu_background_image, (0, 0))  # Dibujar la imagen de fondo del menú
        draw_text("Battle Arena", font, GREEN, screen, SCREEN_WIDTH // 4, SCREEN_HEIGHT // 4)
        draw_text("Press 'ENTER' to Start", font, WHITE, screen, SCREEN_WIDTH // 4, SCREEN_HEIGHT // 2)
        draw_text("Press 'ESC' to Quit", font, WHITE, screen, SCREEN_WIDTH // 4, SCREEN_HEIGHT // 1.5)

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Iniciar el juego
                    game_loop()
                if event.key == pygame.K_ESCAPE:  # Salir del juego
                    pygame.quit()
                    sys.exit()

# Clase Jugador
class Jugador(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        try:
            self.image = pygame.image.load("winer.png")  # Cargar la imagen del jugadorr
            self.image = pygame.transform.scale(self.image, (50, 50))  # Dimensionar la imagen a 50x50
        except pygame.error as e:
            print(f"No se pudo cargar la imagen del jugador: {e}")
            pygame.quit()
            sys.exit()
        self.rect = self.image.get_rect()
        self.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        self.velocidad = 5

    def update(self, keys):
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.velocidad
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.velocidad
        if keys[pygame.K_UP]:
            self.rect.y -= self.velocidad
        if keys[pygame.K_DOWN]:
            self.rect.y += self.velocidad

# Clase Agente IA
class Agente(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        try:
            self.image = pygame.image.load("gost.png")  # Cargar la imagen del enemigo
            self.image = pygame.transform.scale(self.image, (50, 50))  # Dimensionar la imagen a 50x50
        except pygame.error as e:
            print(f"No se pudo cargar la imagen del enemigo: {e}")
            pygame.quit()
            sys.exit()
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.start_time = pygame.time.get_ticks()  # Tiempo de inicio

    def update(self, jugador):
        # Esperar 3 segundos antes de moverse
        if pygame.time.get_ticks() - self.start_time < 3000:
            return

        # Movimiento simple hacia el jugador (IA básica)
        if self.rect.x < jugador.rect.x:
            self.rect.x += 2
        if self.rect.x > jugador.rect.x:
            self.rect.x -= 2
        if self.rect.y < jugador.rect.y:
            self.rect.y += 2
        if self.rect.y > jugador.rect.y:
            self.rect.y -= 2

# Clase Bala
class Bala(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((20, 10))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.velocidad = 10

    def update(self):
        self.rect.x += self.velocidad
        if self.rect.left > SCREEN_WIDTH:
            self.kill()

# Función principal del juego
def game_loop(num_enemigos=5):
    # Crear el jugador y los agentes
    jugador = Jugador()
    agentes = pygame.sprite.Group()
    balas = pygame.sprite.Group()

    # Crear algunos agentes IA
    for _ in range(num_enemigos):
        while True:
            x = random.randint(50, SCREEN_WIDTH - 50)
            y = random.randint(50, SCREEN_HEIGHT - 50)
            agente = Agente(x, y)
            if not pygame.sprite.spritecollideany(agente, agentes):
                agentes.add(agente)
                break

    # Crear un grupo de sprites para el jugador
    all_sprites = pygame.sprite.Group()
    all_sprites.add(jugador)
    all_sprites.add(agentes)

    # Configuración del reloj
    clock = pygame.time.Clock()

    # Bucle principal del juego
    game_running = True
    while game_running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:  # Salir durante el juego
                    game_running = False
                if event.key == pygame.K_SPACE:  # Disparar una bala
                    bala = Bala(jugador.rect.right, jugador.rect.centery)
                    all_sprites.add(bala)
                    balas.add(bala)
                    disparo_sound.play()

        # Actualizar el estado del juego
        keys = pygame.key.get_pressed()
        jugador.update(keys)
        agentes.update(jugador)
        balas.update()

        # Verificar colisiones entre balas y agentes
        for bala in balas:
            hits = pygame.sprite.spritecollide(bala, agentes, True)
            if hits:
                bala.kill()

        # Verificar si un agente ha alcanzado al jugador (fin del juego)
        if pygame.sprite.spritecollide(jugador, agentes, False):
            draw_text("¡Has sido alcanzado! Perdiste.", font, WHITE, screen, SCREEN_WIDTH // 4, SCREEN_HEIGHT // 2)
            pygame.display.update()
            pygame.time.wait(2000)  # Esperar 2 segundos antes de reiniciar
            game_running = False

        # Verificar si no quedan enemigos
        if len(agentes) == 0:
            draw_text("Eres un ganador!!!", font, GREEN, screen, SCREEN_WIDTH // 4, SCREEN_HEIGHT // 2)
            pygame.display.update()
            pygame.time.wait(2000)  # Esperar 2 segundos antes de iniciar la siguiente ronda
            game_loop(num_enemigos * 2)  # Iniciar la siguiente ronda con el doble de enemigos
            return

        # Dibujar todo
        screen.blit(game_background_image, (0, 0))  # Dibujar la imagen de fondo del juego
        all_sprites.draw(screen)

        # Actualizar la pantalla
        pygame.display.update()

        # Controlar los fotogramas por segundo (FPS)
        clock.tick(60)

    # Volver al menú principal
    main_menu()

if __name__ == "__main__":
    main_menu()